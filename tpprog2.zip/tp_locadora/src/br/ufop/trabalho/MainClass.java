package br.ufop.trabalho;

import br.ufop.trabalho.IOConsole.MenuConsole;

public class MainClass {
	
	public static void main(String args[]){
		MenuConsole mc = new MenuConsole();
		mc.inicioExecucao();
	}

}
